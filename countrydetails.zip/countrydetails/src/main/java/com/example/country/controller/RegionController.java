package com.example.country.controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.country.service.RegionService;

import java.util.List;

@RestController    
@CrossOrigin(origins = "*", allowedHeaders = "*")

public class RegionController {

    private final RegionService regionService;

    public RegionController(RegionService regionService) {
        this.regionService = regionService;
    }

    @GetMapping("/unique-regions")
    public List<String> getRegionNames() {
        return regionService.getRegionNames();
    }
}
