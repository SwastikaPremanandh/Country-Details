package com.example.country.service;

import com.example.country.aspectj.Loggable;
import com.example.country.data.*;
import com.example.country.service.CountryService;

import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Service
public class CurrencyService {
    private final RestTemplate restTemplate;

    public CurrencyService(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }
	
    @Cacheable(value="currencynames")
	@Loggable
    public List<String> getCurrencyNames() {
    		CountryService countryService = new CountryService(restTemplate);

			List<Country> allCountries = countryService.fetchAndSaveData();
			Set<String> uniqueCurrencies = new HashSet<>();
	        for (Country country : allCountries) {
	        	for (String currency : country.getCurrencies()) {
	                uniqueCurrencies.add(currency);
	            }	        	}
	        return new ArrayList<>(uniqueCurrencies);
    }
    	
}

