package com.example.country.service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.example.country.aspectj.Loggable;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.JsonNode;


import com.example.country.data.Country;
import com.example.country.data.PageData;

@Service
public class 																																																					CountryService {

//	@Value("${api.url}")
	private String apiUrl = "https://jsonmock.hackerrank.com/api/countries";
	private static final int TOTAL_PAGES = 25;
	@Autowired
	private final RestTemplate restTemplate;

	public CountryService(RestTemplate restTemplate) {
		this.restTemplate = restTemplate;
	}

	private List<Country> fetchCountriesFromApi(int page) {
		String url = apiUrl + "?page=" + page;
		ResponseEntity<PageData> responseEntity = restTemplate.exchange(url, HttpMethod.GET, null, PageData.class);
		PageData pageData = responseEntity.getBody();
		return pageData != null ? pageData.getCountries() : new ArrayList<>();
	}

	public List<Country> fetchAndSaveData() {
		List<Country> allCountries = new ArrayList<>();
		for (int page = 1; page <= TOTAL_PAGES; page++) {
			List<Country> countries = fetchCountriesFromApi(page);
			allCountries.addAll(countries);
		}
		return allCountries;
	}
	@Cacheable(value="countrydetailsbysearch")

	public List<Country> getCountriesByNameContaining(String search) {
		List<Country> allCountries = new ArrayList<>();
		for (int page = 1; page <= TOTAL_PAGES; page++) {
			List<Country> countries = fetchCountriesFromApi(page);
			for (Country country : countries) {
				if (country.getName() != null && country.getName().toLowerCase().contains(search.toLowerCase())) {
					allCountries.add(country);
				}
			}
		}
		return allCountries;
	}

	public List<Country> getCountriesByPopulationRange(int minPopulation, int maxPopulation) {
		List<Country> countriesInRange = new ArrayList<>();
		for (int page = 1; page <= TOTAL_PAGES; page++) {
			List<Country> countries = fetchCountriesFromApi(page);
			for (Country country : countries) {
				int population = country.getPopulation();
				if (population >= minPopulation && population <= maxPopulation) {
					countriesInRange.add(country);
				}
			}
		}
		return countriesInRange;
	}

	public List<Country> getCountriesByRegion(String region) {
		List<Country> countriesInRegion = new ArrayList<>();
		for (int page = 1; page <= TOTAL_PAGES; page++) {
			List<Country> countries = fetchCountriesFromApi(page);
			for (Country country : countries) {

				if (country.getRegion().equalsIgnoreCase(region)) {
					countriesInRegion.add(country);
				}
			}
		}
		return countriesInRegion;
	}

	public List<Country> getCountriesByAreaRange(int minArea, int maxArea) {
		List<Country> countriesInRange = new ArrayList<>();

		List<Country> allCountries = fetchAndSaveData();
		for (Country country : allCountries) {
			double area = country.getArea();
			if (area >= minArea && area <= maxArea) {
				countriesInRange.add(country);
			}
		}

		return countriesInRange;
	}

	
	public List<Country> getCountriesByCurrency(String currency) {
		List<Country> countriesWithCurrency = new ArrayList<>();

		List<Country> allCountries = fetchAndSaveData();
		for (Country country : allCountries) {
			if (country.getCurrencies().contains(currency.toUpperCase())) {
				countriesWithCurrency.add(country);
			}
		}

		return countriesWithCurrency;
	}
	@Cacheable(value="allfilters")
	@Loggable
	public List<Country> filterCountries(String currency, String region, Integer minPopulation, Integer maxPopulation,Integer minArea, Integer maxArea, String search) {
		List<Country> allCountries = fetchAndSaveData();

		List<Country> filteredCountries = new ArrayList<>();
		for (Country country : allCountries) {
			if (currency == null && region == null && minPopulation == null && maxPopulation == null && minArea == null && maxArea == null && search == null) {
		        return allCountries;
		    }
			if ((currency == null || country.getCurrencies().contains(currency.toUpperCase()))
					&& (region == null || country.getRegion().equalsIgnoreCase(region))
					&& (minPopulation == null || country.getPopulation() >= minPopulation)
					&& (maxPopulation == null || country.getPopulation() <= maxPopulation)
					&& (minArea == null || country.getArea() >= minArea)
					&& (maxArea == null || country.getArea() <= maxArea)
					&& (search == null || country.getName().toLowerCase().equals(search.toLowerCase()))) {

				filteredCountries.add(country);
			}

		}
		return filteredCountries;
	}

}
