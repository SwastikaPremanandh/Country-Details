package com.example.country.controller;

import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.country.service.CountryService;
import com.example.country.data.*;

@RestController

@CrossOrigin(origins = "*", allowedHeaders = "*")

@RequestMapping("/api")
public class CountryController {

    private final CountryService countryService;

    @Autowired
    public CountryController(CountryService countryService) {
        this.countryService = countryService;
    }

    @RequestMapping(value="countries",method=RequestMethod.GET,consumes=MediaType.ALL_VALUE,produces=MediaType.APPLICATION_JSON_VALUE)
    public List<Country> fetchCountriesData() {
        
            return countryService.fetchAndSaveData();
    }
    @RequestMapping(value="name",method=RequestMethod.GET,consumes=MediaType.ALL_VALUE,produces=MediaType.APPLICATION_JSON_VALUE)
    public List<Country> getCountriesByNameContaining(@RequestParam String search)
    {
        return countryService.getCountriesByNameContaining(search);

    }
    @RequestMapping(value = "population-range", method = RequestMethod.GET, consumes = MediaType.ALL_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public List<Country> getCountriesByPopulationRange(@RequestParam int minPopulation, @RequestParam int maxPopulation) {
        return countryService.getCountriesByPopulationRange(minPopulation, maxPopulation);
    }
    @GetMapping(value = "currencies", produces = MediaType.APPLICATION_JSON_VALUE)
    public List<Country> getCountriesByCurrency(@RequestParam String currency) {
        return countryService.getCountriesByCurrency(currency);
    }

    @GetMapping(value = "region", produces = MediaType.APPLICATION_JSON_VALUE)
    public List<Country> getCountriesByRegion(@RequestParam String region) {
        return countryService.getCountriesByRegion(region);
    }

    @GetMapping(value = "area", produces = MediaType.APPLICATION_JSON_VALUE)
    public List<Country> getCountriesByAreaRange(@RequestParam int minArea, @RequestParam int maxArea) {
        return countryService.getCountriesByAreaRange(minArea, maxArea);
    }
    @GetMapping(value = "filter", produces = MediaType.APPLICATION_JSON_VALUE)

    public List<Country> filterCountries(
            @RequestParam(required = false) String currency,
            @RequestParam(required = false) String region,
            @RequestParam(required = false) Integer minPopulation,
            @RequestParam(required = false) Integer maxPopulation,
            @RequestParam(required = false) Integer minArea,
            @RequestParam(required = false) Integer maxArea,
            @RequestParam(required = false) String search) {

        List<Country> filteredCountries = countryService.filterCountries(currency, region, minPopulation, maxPopulation, minArea, maxArea, search);

        return filteredCountries;
}


}

