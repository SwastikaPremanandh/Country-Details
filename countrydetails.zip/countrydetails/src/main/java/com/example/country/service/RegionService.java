package com.example.country.service;

import com.example.country.aspectj.Loggable;
import com.example.country.data.*;
import com.example.country.service.CountryService;

import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Service
public class RegionService {
    private final RestTemplate restTemplate;

    public RegionService(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }
	@Cacheable(value="regionNames")
	@Loggable
    public List<String> getRegionNames() {
    		CountryService countryService = new CountryService(restTemplate);

			List<Country> allCountries = countryService.fetchAndSaveData();
			Set<String> uniqueRegions = new HashSet<>();
	        for (Country country : allCountries) {
	            uniqueRegions.add(country.getRegion());
	        }
	        return new ArrayList<>(uniqueRegions);
    }
    	
}

