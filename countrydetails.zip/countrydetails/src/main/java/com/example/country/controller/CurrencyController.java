package com.example.country.controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.country.service.CurrencyService;

import java.util.List;

@RestController
@CrossOrigin(origins = "*", allowedHeaders = "*")

public class CurrencyController {

    private final CurrencyService CurrencyService;

    public CurrencyController(CurrencyService CurrencyService) {
        this.CurrencyService = CurrencyService;
    }

    @GetMapping("/unique-currencies")
    public List<String> getCurrencyNames() {
        return CurrencyService.getCurrencyNames();
    }
}
