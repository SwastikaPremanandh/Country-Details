package com.example.country.data;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Country {
	@JsonProperty("name")
    private String name;
	
	@JsonProperty("nativeName")
    private String nativeName;
	@JsonProperty("topLevelDomain")

    private List<String> topLevelDomain;
	@JsonProperty("alpha2Code")

    private String alpha2Code;
	@JsonProperty("numericCode")

    private String numericCode;
	@JsonProperty("alpha3Code")

    private String alpha3Code;
	@JsonProperty("currencies")

    private List<String> currencies;
	@JsonProperty("callingCodes")

    private List<String> callingCodes;
	@JsonProperty("capital")

    private String capital;
	@JsonProperty("altSpellings")

    private List<String> altSpellings;
	@JsonProperty("relevance")

    private String relevance;
	
	@JsonProperty("region")
	private String region;
	
	@JsonProperty("subregion")

    private String subregion;
	@JsonProperty("language")

    private List<String> language;
	@JsonProperty("languages")

    private List<String> languages;
	@JsonProperty("translations")

    private Translations translations;
	@JsonProperty("population")

    private int population;
	@JsonProperty("latlng")

    private List<Double> latlng;
	@JsonProperty("demonym")

    private String demonym;
	@JsonProperty("borders")

    private List<String> borders;
	@JsonProperty("area")

    private double area;
	@JsonProperty("timezones")

    private List<String> timezones;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getNativeName() {
		return nativeName;
	}
	public void setNativeName(String nativeName) {
		this.nativeName = nativeName;
	}
	public List<String> getTopLevelDomain() {
		return topLevelDomain;
	}
	public void setTopLevelDomain(List<String> topLevelDomain) {
		this.topLevelDomain = topLevelDomain;
	}
	public String getAlpha2Code() {
		return alpha2Code;
	}
	public void setAlpha2Code(String alpha2Code) {
		this.alpha2Code = alpha2Code;
	}
	public String getNumericCode() {
		return numericCode;
	}
	public void setNumericCode(String numericCode) {
		this.numericCode = numericCode;
	}
	public String getAlpha3Code() {
		return alpha3Code;
	}
	public void setAlpha3Code(String alpha3Code) {
		this.alpha3Code = alpha3Code;
	}
	public List<String> getCurrencies() {
		return currencies;
	}
	public void setCurrencies(List<String> currencies) {
		this.currencies = currencies;
	}
	public List<String> getCallingCodes() {
		return callingCodes;
	}
	public void setCallingCodes(List<String> callingCodes) {
		this.callingCodes = callingCodes;
	}
	public String getCapital() {
		return capital;
	}
	public void setCapital(String capital) {
		this.capital = capital;
	}
	public List<String> getAltSpellings() {
		return altSpellings;
	}
	public void setAltSpellings(List<String> altSpellings) {
		this.altSpellings = altSpellings;
	}
	public String getRelevance() {
		return relevance;
	}
	public void setRelevance(String relevance) {
		this.relevance = relevance;
	}
	public String getRegion() {
		return region;
	}
	public void setRegion(String region) {
		this.region = region;
	}
	public String getSubregion() {
		return subregion;
	}
	public void setSubregion(String subregion) {
		this.subregion = subregion;
	}
	public List<String> getLanguage() {
		return language;
	}
	public void setLanguage(List<String> language) {
		this.language = language;
	}
	public List<String> getLanguages() {
		return languages;
	}
	public void setLanguages(List<String> languages) {
		this.languages = languages;
	}
	public Translations getTranslations() {
		return translations;
	}
	public void setTranslations(Translations translations) {
		this.translations = translations;
	}
	public int getPopulation() {
		return population;
	}
	public void setPopulation(int population) {
		this.population = population;
	}
	public List<Double> getLatlng() {
		return latlng;
	}
	public void setLatlng(List<Double> latlng) {
		this.latlng = latlng;
	}
	public String getDemonym() {
		return demonym;
	}
	public void setDemonym(String demonym) {
		this.demonym = demonym;
	}
	public List<String> getBorders() {
		return borders;
	}
	public void setBorders(List<String> borders) {
		this.borders = borders;
	}
	public double getArea() {
		return area;
	}
	public void setArea(double area) {
		this.area = area;
	}
	public List<String> getTimezones() {
		return timezones;
	}
	public void setTimezones(List<String> timezones) {
		this.timezones = timezones;
	}
    
}