package com.example.country.service;
import com.example.country.aspectj.Loggable;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.example.country.data.Country;
@Service
public class NameService {
	private final RestTemplate restTemplate;

    public NameService(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

	@Cacheable(value="countrynames")
	@Loggable
	public List<String> getName() {
		CountryService countryService = new CountryService(restTemplate);

		List<Country> allCountries = countryService.fetchAndSaveData();
		Set<String> uniqueCountryNames = new HashSet<>();
        for (Country country : allCountries) {
        	uniqueCountryNames.add(country.getName());
        }
        return new ArrayList<>(uniqueCountryNames);
	}

}
