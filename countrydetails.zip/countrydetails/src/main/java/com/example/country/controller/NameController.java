package com.example.country.controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.country.service.NameService;

import java.util.List;

@RestController    
@CrossOrigin(origins = "*", allowedHeaders = "*")

public class NameController {

    private final NameService nameService;

    public NameController(NameService nameService) {
        this.nameService = nameService;
    }

    @GetMapping("/unique-country-names")
    public List<String> getName() {
        return nameService.getName();
    }
}
