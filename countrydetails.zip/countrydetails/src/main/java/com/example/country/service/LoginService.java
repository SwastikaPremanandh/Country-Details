package com.example.country.service;
import com.example.country.data.Login;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.fasterxml.jackson.databind.SerializationFeature;
import org.springframework.stereotype.Service;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
@Service
public class LoginService {

    private static final String FILE_PATH = "D:\\country\\src\\main\\java\\users.json";
    public List<Login> getAllUsers() { //to display all users in the file
        List<Login> users = new ArrayList<>();
        ObjectMapper objectMapper = new ObjectMapper();
        try {
            users = objectMapper.readValue(new File(FILE_PATH), objectMapper.getTypeFactory().constructCollectionType(List.class, Login.class));
        } catch (IOException e) {
            e.printStackTrace();
        }
        return users;
    }
    public boolean addUser(String email, String password) { //adds user to .json file
        List<Login> logins = new ArrayList<>(loadLogins());
        for (Login Login : logins) {
            if (Login.getEmail().equals(email)) {
                return false;
            }
        }
        Login newLogin = new Login(email, password);
        logins.add(newLogin);
        saveLogins(logins);
        return true;
    }

    public boolean checkUser(String email, String password) {  //for login,it checks the entered input with the data in file.

        List<Login> Logins = loadLogins();
        for (Login login : Logins) {

            if  (login.getEmail().equalsIgnoreCase(email) && login.getPassword().equalsIgnoreCase(password)) {
                return true;
            }
        }
        return false;
    }
private List<Login> loadLogins() { //loadlogins function is for reading data from json file
    List<Login> logins = new ArrayList<>();
    ObjectMapper objectMapper = new ObjectMapper();
    try {
        File file = new File(FILE_PATH);
        if (!file.exists()) {
            return logins;
        }
        Login[] loginArray = objectMapper.readValue(file, Login[].class);
        logins = Arrays.asList(loginArray);
    } catch (IOException e) {
        e.printStackTrace();
    }
    return logins;
}

    private void saveLogins(List<Login> logins) { //saveLogins function is to write data into json file
        ObjectMapper objectMapper = new ObjectMapper();
        objectMapper.enable(SerializationFeature.INDENT_OUTPUT);
        ObjectWriter objectWriter = objectMapper.writerWithDefaultPrettyPrinter();
        try {
            objectWriter.writeValue(new File(FILE_PATH), logins);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }




}
