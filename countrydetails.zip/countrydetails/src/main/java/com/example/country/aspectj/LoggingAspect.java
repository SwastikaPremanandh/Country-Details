package com.example.country.aspectj;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.stereotype.Component;
import org.springframework.util.StopWatch;

@Aspect
@Component
public class LoggingAspect
{
    private static final Logger LOGGER = LogManager.getLogger(LoggingAspect.class);
    @interface Loggable {}
    @Around("@annotation(com.example.country.aspectj.Loggable)")
    public Object profileAllMethods(ProceedingJoinPoint proceedingJoinPoint) throws Throwable
    {
        MethodSignature methodSignature = (MethodSignature) proceedingJoinPoint.getSignature();

        String className = methodSignature.getDeclaringType().getSimpleName();
        String methodName = methodSignature.getName();

        long start_time=System.currentTimeMillis();
        Object result = proceedingJoinPoint.proceed();
        long end_time=System.currentTimeMillis();

        LOGGER.info("Execution time of " + className + "." + methodName + " :: " + (end_time-start_time) + " ms");

        return result;
    }
}



