package com.example.country.controller;

import com.example.country.data.Login;
import com.example.country.service.LoginService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin(origins = "*", allowedHeaders = "*")

@RequestMapping("/api")
public class LoginController {

    private final LoginService loginService;

    public LoginController(LoginService loginService) {
        this.loginService = loginService;
    }

    @PostMapping("/users")
    public ResponseEntity<String> addUser(@RequestBody Login userDTO) {
        String email = userDTO.getEmail();
        String password = userDTO.getPassword();
        System.out.println(email+" "+password);
        boolean added = loginService.addUser(email, password);
        if (added) {
            return ResponseEntity.ok("User added successfully");
        } else {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("User already exists");
        }
    }

    @GetMapping("/login")
    public ResponseEntity<String> login(@RequestParam String email, @RequestParam String password) {
        String extractedEmail = email.split(",")[1].trim();
        String extractedPassword = password.split(",")[1].trim();
        boolean loggedIn = loginService.checkUser(extractedEmail, extractedPassword);

        if (loggedIn) {
            return ResponseEntity.ok("Login successful");
        } else {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Login failed");
        }
    }
    @GetMapping("/user")
    public ResponseEntity<List<Login>> getAllUsers() {
        List<Login> users = loginService.getAllUsers();
        return ResponseEntity.ok(users);
    }
}
