import { useEffect, useRef, useState } from "preact/hooks";
import "ojs/ojdialog";
import { ojDialog } from "ojs/ojdialog";

import ArrayDataProvider = require("ojs/ojarraydataprovider");
import 'ojs/ojselectsingle';
import "ojs/ojbutton";
import PopulationRangeSlider from "./PopulationRangeSlider";
import AreaRangeSlider from "./AreaRangeSlider";
type Props = {
    isOpened: boolean;
    closeDialog: (ref)=> void;
    setSelectedRegion: (region: string) => void;
    setSelectedCurrency: (currency: string) => void;
    min: number;
    max: number;
    value: { start: number; end: number };
    onRangeChange: (value: { start: number; end: number }) => void;
    areamin:number;
    areamax:number;
    areavalue:{start:number;end:number};
    onAreaChange:(areavalue:{start:number;end:number}) => void;
    onDone: () => void;

};

type Option = {
    value: string;
    label: string;
};

const AdvancedOptions = (props: Props) => {
    const [regions, setRegions] = useState<Option[]>([]);
    const [currencies, setCurrencies] = useState<Option[]>([]);
    const dialogRef = useRef<ojDialog>(null);
    const handleDoneClick = () => {
        props.onDone();
        closeDialog(dialogRef);
    };

    const closeDialog = (ref) => {
        console.log('hi');

    }

    useEffect(() => {
        props.isOpened
            ? dialogRef.current.open()
            : dialogRef.current.close();
    }, [props.isOpened]);

    useEffect(() => {
        const fetchRegions = async () => {
            try {
                const response = await fetch(`http://localhost:8080/unique-regions`, {
                    headers: {
                        'Authorization': `Basic ${btoa('country:country@123')}`
                    }
                });
                if (!response.ok) {
                    throw new Error('Failed to fetch regions');
                }
                const data = await response.json();
                const mappedData: Option[] = data.map((value: string) => ({
                    value,
                    label: value
                }));
                setRegions(mappedData);
            } catch (error) {
                console.error('Error fetching regions:', error);
            }
        };

        const fetchCurrencies = async () => {
            try {
                const response = await fetch('http://localhost:8080/unique-currencies',{
                    headers:{
                        'Authorization': `Basic ${btoa('country:country@123')}`
                    }
                })
                if (!response.ok) {
                    throw new Error('Failed to fetch currencies');
                }
                const data = await response.json();
                const mappedData: Option[] = data.map((value: string) => ({
                    value,
                    label: value
                }));
                setCurrencies(mappedData);
            } catch (error) {
                console.error('Error fetching currencies:', error);
            }
        };

        fetchRegions();
        fetchCurrencies();
    }, []);

    return (
        <>
            <oj-dialog ref={dialogRef} dialogTitle="Advanced Options" onojClose={closeDialog} modality={"modeless"}

            >
                <div slot="body">
                    <oj-form-layout>

                        <oj-select-single
                            id="regionSelect"
                            label-hint="Region"
                            data={new ArrayDataProvider(regions, {keyAttributes: 'value'})}
                            onvalueChanged={(event: any) => props.setSelectedRegion(event.detail.value)}
                        ></oj-select-single>
                        <oj-select-single
                            id="currencySelect"
                            label-hint="Currency"
                            data={new ArrayDataProvider(currencies, {keyAttributes: 'value'})}
                            onvalueChanged={(event: any) => props.setSelectedCurrency(event.detail.value)}
                        ></oj-select-single>
                        <PopulationRangeSlider min={props.min} max={props.max} value={props.value}
                                               onRangeChange={props.onRangeChange}/>
                        <AreaRangeSlider areamin={props.areamin} areamax={props.areamax} areavalue={props.areavalue}
                                         onAreaChange={props.onAreaChange}/>
                        <oj-button id="doneBtn" onojAction={handleDoneClick}>Done</oj-button>
                    </oj-form-layout>

                </div>


                <div slot="footer">
                    <oj-button id="cancelBtn" onojAction={closeDialog}>Cancel</oj-button>

                </div>
            </oj-dialog>
        </>
    );
};
export default AdvancedOptions;
