import { h } from "preact";
import { useState } from "preact/hooks";

import "ojs/ojslider";
import "ojs/ojformlayout";
import "ojs/ojlabel";

const PopulationRangeSlider = ({ min, max, value, onRangeChange }) => {

    const handleValueChange = (event) => {
        onRangeChange(event.detail.value);
    };

    return (
        <div id="sampleDemo" className="demo-padding demo-container">
            <div id="componentDemoContent" style={{ width: "1px", minWidth: "100%" }}>
                <div id="range-slider-container">
                    <oj-form-layout>
                        <oj-range-slider
                            id="population-range-slider"
                            value={value}
                            min={min}
                            max={max}
                            // transient-value={transientValue}
                            onvalueChanged={handleValueChange}
                            label-hint="Population Range"
                            label-edge="inside"
                            step={1000000}
                        ></oj-range-slider>

                        <oj-label>Start and end value for Population Range Slider</oj-label>
                        <span id="values">{`${value.start} , ${value.end}`}</span>
                    </oj-form-layout>
                </div>
            </div>
        </div>
    );
};

export default PopulationRangeSlider;
