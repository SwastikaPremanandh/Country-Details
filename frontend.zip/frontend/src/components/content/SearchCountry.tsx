import {useEffect, useState} from "preact/hooks";
import "ojs/ojinputsearch";
import "ojs/ojbutton";
import "ojs/ojinputtext";
import "ojs/ojtable";

import AdvancedOptions from "./AdvancedOptions";
import ArrayDataProvider = require("ojs/ojarraydataprovider");

const SearchCountry = () => {
    const [val, setVal] = useState('');
    const [suggestions, setSuggestions] = useState([]);
    const [countryDetails, setCountryDetails] = useState([]);
    const [isAdvancedOptionsOpen, setIsAdvancedOptionsOpen] = useState(false);
    const [selectedRegion, setSelectedRegion] = useState<string>("");
    const [selectedCurrency, setSelectedCurrency] = useState<string>("");
    const [filterDetails, setFilterDetails] = useState([]);
    const [isSubmitExecuted, setIsSubmitExecuted] = useState(false);
    const [isDataFound, setIsDataFound] = useState(true);
    const [rangeValue, setRangeValue] = useState({start: 0, end: 1400000000});
    const [areaValue, setAreaValue] = useState({start: 0, end: 18000000});
    const [isAdvancedOptionsDone, setIsAdvancedOptionsDone] = useState(false);
    const [dataArray, setDataArray] = useState([]);

    const handleRangeChange = (rangeValue) => {
        setRangeValue(rangeValue);
    };
    const handleAreaChange = (areaValue) => {
        setAreaValue(areaValue);
    };
    const openAdvancedOptions = () => {
        setIsAdvancedOptionsOpen(true);
    };

    const closeAdvancedOptions = (ref) => {
        setIsAdvancedOptionsOpen(false);
        if (ref && ref.current) {
            ref.current.close();
        }
    };


    useEffect(() => {
        fetchSuggestions();
    }, []);

    const fetchSuggestions = async () => {
        try {
            const response = await fetch('http://localhost:8080/unique-country-names', {
                headers: {
                    'Authorization': `Basic ${btoa('country:country@123')}`
                }
            });

            if (!response.ok) {
                throw new Error('Failed to fetch suggestions');
            }

            const data = await response.json();
            const countryArray = data.map((country) => ({value: country, label: country}));
            setSuggestions(countryArray);
        } catch (error) {
            console.error('Error fetching suggestions:', error);
        }
    };

    const handleValueChanged = (event) => {
        setVal(event.target.value);
    };

    const handleSubmit = async () => {


        if (val) {
            try {
                const response = await fetch(`http://localhost:8080/api/filter?search=${val}`, {
                    headers: {
                        'Authorization': `Basic ${btoa('country:country@123')}`
                    }
                });

                if (!response.ok) {
                    throw new Error('Failed to retrieve country details');
                }

                const countryDetails = await response.json();
                const newData = countryDetails.map(country => ({
                    "name": country.name,
                    "nativeName": country.nativeName,
                    "capital": country.capital,
                    "region": country.region,
                    "subregion": country.subregion,
                    "area": country.area,
                    "population": country.population,
                    "currencies": country.currencies.join(', ')
                }));

                setCountryDetails(newData);
                setIsSubmitExecuted(true);
            } catch (error) {
                console.error('Error retrieving country details:', error);
                alert('Error retrieving country details. Please try again.');
            }
        }

    }
    const handleAdvancedOptionsDone = async () => {
        setIsAdvancedOptionsDone(true);


        try {
            let apiUrl = 'http://localhost:8080/api/filter?';

            if (selectedCurrency) {
                apiUrl += `currency=${selectedCurrency}&`;
            }

            if (selectedRegion) {
                apiUrl += `region=${selectedRegion}&`;
            }

            if (areaValue && areaValue.start !== undefined && areaValue.end !== undefined) {
                apiUrl += `minArea=${areaValue.start}&maxArea=${areaValue.end}&`;
            }

            if (rangeValue && rangeValue.start !== undefined && rangeValue.end !== undefined) {
                apiUrl += `minPopulation=${rangeValue.start}&maxPopulation=${rangeValue.end}&`;
            }

            apiUrl = apiUrl.replace(/&$/, '');

            const response = await fetch(apiUrl, {
                headers: {
                    'Authorization': `Basic ${btoa('country:country@123')}`
                }
            });

            if (!response.ok) {
                throw new Error(`Failed to fetch data from ${apiUrl}`);
            }

            const filterDetails = await response.json();
            const filterData = filterDetails.map(country => ({
                "name": country.name,
                "nativeName": country.nativeName,
                "capital": country.capital,
                "region": country.region,
                "subregion": country.subregion,
                "area": country.area,
                "population": country.population,
                "currencies": country.currencies.join(', ')
            }));
            setFilterDetails(filterData);

            if (filterData.length > 0) {
                setIsDataFound(true);
            } else {
                setIsDataFound(false);
            }
        } catch (error) {
            console.error("Error fetching data:", error);
        }

    };
    useEffect(() => {
        if (isSubmitExecuted) {
            setDataArray(countryDetails);
            setIsSubmitExecuted(false);
        } else if (isAdvancedOptionsDone) {
            setDataArray(filterDetails);
            setIsAdvancedOptionsDone(false);
        }
    }, [isSubmitExecuted, isAdvancedOptionsDone, countryDetails, filterDetails]);

    return (
        <div className="oj-web-applayout-max-width oj-web-applayout-content">
            <div slot="body">
                <oj-form-layout max-columns="3" direction="row">
                    <oj-input-search
                        id="search1"
                        class="oj-input-search-hero custom-input-search"
                        suggestions={new ArrayDataProvider(suggestions, {keyAttributes: "value"})}
                        placeholder="Search..."
                        onvalueChanged={handleValueChanged}
                        value={val}
                        aria-label="My search field"
                    />
                    <oj-button id="submit" slot="value" onClick={handleSubmit}>
                        Search Details
                    </oj-button>
                    <oj-button id="Advoptions" onClick={openAdvancedOptions}>
                        Advanced Options
                    </oj-button>
                </oj-form-layout>
                <AdvancedOptions isOpened={isAdvancedOptionsOpen} closeDialog={closeAdvancedOptions}
                                 setSelectedRegion={setSelectedRegion}
                                 setSelectedCurrency={setSelectedCurrency}
                                 min={0}
                                 max={1400000000}
                                 value={rangeValue}
                                 onRangeChange={handleRangeChange}
                                 areamin={0}
                                 areamax={18000000}
                                 areavalue={areaValue}
                                 onAreaChange={handleAreaChange}
                                 onDone={handleAdvancedOptionsDone}

                />
                    {dataArray.length > 0 ? (
                        <oj-table
                            id="countryDetailsTable"
                            aria-label="Country Details Table"
                            data={new ArrayDataProvider(dataArray)}
                            dnd={{"reorder": {"columns": "enabled"}}}
                            scroll-policy="loadMoreOnScroll"
                            scroll-policy-options='{"fetchSize": 10}'
                            columns={[
                                {
                                    "headerText": "Name",
                                    "field": "name",
                                    "headerClassName": "oj-sm-only-hide",
                                    "className": "oj-sm-only-hide",
                                    "resizable": "enabled",
                                    "id": "name"
                                },
                                {
                                    "headerText": "Native Name",
                                    "field": "nativeName",
                                    "resizable": "enabled",
                                    "id": "nativeName"
                                },
                                {
                                    "headerText": "Capital",
                                    "field": "capital",
                                    "headerClassName": "oj-sm-only-hide",
                                    "className": "oj-sm-only-hide",
                                    "resizable": "enabled",
                                    "id": "capital"
                                },
                                {
                                    "headerText": "Region",
                                    "field": "region",
                                    "resizable": "enabled",
                                    "id": "region"
                                },
                                {
                                    "headerText": "Subregion",
                                    "field": "subregion",
                                    "headerClassName": "oj-md-down-hide",
                                    "className": "oj-md-down-hide",
                                    "resizable": "enabled",
                                    "id": "subregion"
                                },
                                {
                                    "headerText": "Area",
                                    "field": "area",
                                    "headerClassName": "oj-md-down-hide",
                                    "className": "oj-md-down-hide",
                                    "resizable": "enabled",
                                    "id": "area"
                                },
                                {
                                    "headerText": "Population",
                                    "field": "population",
                                    "headerClassName": "oj-md-down-hide",
                                    "className": "oj-md-down-hide",
                                    "resizable": "enabled",
                                    "id": "population"
                                },
                                {
                                    "headerText": "Currencies",
                                    "field": "currencies",
                                    "headerClassName": "oj-md-down-hide",
                                    "className": "oj-md-down-hide",
                                    "resizable": "enabled",
                                    "id": "currencies"
                                }
                            ]}
                            class="country-details-table-container"
                        />
                    ) : (
                        !isDataFound && (
                            <div className="no-match-found-text">No match found</div>
                        )
                    )}


            </div>

        </div>

    );
};

export default SearchCountry;
