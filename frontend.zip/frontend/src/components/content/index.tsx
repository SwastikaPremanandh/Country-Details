import "ojs/ojlabel";
import "ojs/ojinputtext";
import { useState } from "preact/hooks";
import "ojs/ojformlayout";
import "ojs/ojbutton";
import SearchCountry from "./SearchCountry";

const Content = () => {
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [loggedIn, setLoggedIn] = useState(false);
    const username = 'country';
    const pass = 'country@123';

    const basicAuth = btoa(`${username}:${pass}`);
    const login = async () => {
        try {
            let res = await fetch("http://localhost:8080/api/user", {
                method: "GET",
                headers: {
                    "Content-type": "application/json",
                    "Authorization": `Basic ${basicAuth}`
                }

            });
            let response = await res.json();
            console.log("response", response);
            let credentialsMatch = false;
            for (let userKey in response) {
                let user = response[userKey];
                if (user.email === email && user.password === password) {
                    credentialsMatch = true;
                    break;
                }
            }

            if (credentialsMatch) {
                setLoggedIn(true);
                console.log("Credentials match found.");
            } else {
                alert("Error: Email or password is incorrect");
            }
        } catch (error) {
            console.error("Error:", error);
            alert("Error: Something went wrong. Please try again later.");
        }
    };
    if (loggedIn) {
        return <SearchCountry />;
    }
    const validate = async () => {
        if (!email) {
            window.alert("Please Enter Your Email id");
        } else if (!password) {
            window.alert("Please Enter Your Password");
        } else {
            login();
        }
    };

    const handleSubmit = async (event: Event) => {
        event.preventDefault();
        validate();
    };


    return (
        <div className="oj-web-applayout-max-width oj-web-applayout-content">
            <h1>Login</h1>

            <div className="oj-flex oj-sm-flex-direction-column">
                <div className="oj-flex-item oj-sm-padding-2x-horizontal">
                    <div className="oj-flex">
                        <div className="oj-flex-item oj-md-padding-2x-horizontal">
                            <oj-label for="enteremail">
                                <h5>Email Address:</h5>
                            </oj-label>
                        </div>
                        <oj-input-text
                            value={email}
                            onvalueChanged={(e) => setEmail(e.detail.value)}
                            class="demo-percentage-width"
                            label-hint="Enter Email"
                        ></oj-input-text>
                    </div>
                </div>
                <div className="oj-flex-item oj-sm-padding-2x-horizontal">
                    <div className="oj-flex">
                        <div className="oj-flex-item oj-md-padding-2x-horizontal">
                            <oj-label for="enterpassword">
                                <h5>Password:</h5>
                            </oj-label>
                        </div>
                        <oj-input-password
                            value={password}
                            class="demo-percentage-width"
                            onvalueChanged={(e) => setPassword(e.detail.value)}
                            label-hint="Enter Password"
                            mask-icon="visible"
                        ></oj-input-password>
                    </div>
                </div>


                <div className="oj-flex-item oj-sm-padding-2x-horizontal"
                     style={{display: 'flex', justifyContent: 'center',marginTop: '30px'}}>
                    <div className="oj-flex">
                        <div className="oj-flex-item oj-md-padding-2x-horizontal">
                            <span></span>
                        </div>
                        <oj-button id="submit" slot="value"
                                   onClick={handleSubmit}
                        >
                            Login
                        </oj-button>
                    </div>
                </div>

                {/*<div class="button-container">*/}

                {/*</div>*/}
            </div>
        </div>


    );
};

export default Content;
