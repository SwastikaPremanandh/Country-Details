
import "ojs/ojslider";
import "ojs/ojformlayout";
import "ojs/ojlabel";

const AreaRangeSlider = ({ areamin, areamax, areavalue, onAreaChange }) => {

    const handleAreaChange = (event) => {
        onAreaChange(event.detail.value);
    };

    return (
        <div id="sampleDemo" className="demo-padding demo-container">
            <div id="componentDemoContent" style={{ width: "1px", minWidth: "100%" }}>
                <div id="range-slider-container">
                    <oj-form-layout>
                        <oj-range-slider
                            id="area-range-slider"
                            value={areavalue}
                            min={areamin}
                            max={areamax}
                            onvalueChanged={handleAreaChange}
                            label-hint="Area"
                            label-edge="inside"
                            step={100000}
                        ></oj-range-slider>

                        <oj-label>Start and end value for Area Range Slider</oj-label>
                        <span id="values">{`${areavalue.start} , ${areavalue.end}`}</span>
                    </oj-form-layout>
                </div>
            </div>
        </div>
    );
};

export default AreaRangeSlider;
