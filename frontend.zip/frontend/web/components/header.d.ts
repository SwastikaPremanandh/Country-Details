import { h } from "preact";
import "ojs/ojtoolbar";
import "ojs/ojmenu";
import "ojs/ojbutton";
type Props = Readonly<{
    appName: string;
}>;
export declare function Header({ appName }: Props): h.JSX.Element;
export {};
