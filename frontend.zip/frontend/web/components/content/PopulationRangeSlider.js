define(["require", "exports", "preact/jsx-runtime", "ojs/ojslider", "ojs/ojformlayout", "ojs/ojlabel"], function (require, exports, jsx_runtime_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    const PopulationRangeSlider = ({ min, max, value, onRangeChange }) => {
        const handleValueChange = (event) => {
            onRangeChange(event.detail.value);
        };
        return ((0, jsx_runtime_1.jsx)("div", Object.assign({ id: "sampleDemo", className: "demo-padding demo-container" }, { children: (0, jsx_runtime_1.jsx)("div", Object.assign({ id: "componentDemoContent", style: { width: "1px", minWidth: "100%" } }, { children: (0, jsx_runtime_1.jsx)("div", Object.assign({ id: "range-slider-container" }, { children: (0, jsx_runtime_1.jsxs)("oj-form-layout", { children: [(0, jsx_runtime_1.jsx)("oj-range-slider", { id: "population-range-slider", value: value, min: min, max: max, onvalueChanged: handleValueChange, "label-hint": "Population Range", "label-edge": "inside", step: 1000000 }), (0, jsx_runtime_1.jsx)("oj-label", { children: "Start and end value for Population Range Slider" }), (0, jsx_runtime_1.jsx)("span", Object.assign({ id: "values" }, { children: `${value.start} , ${value.end}` }))] }) })) })) })));
    };
    exports.default = PopulationRangeSlider;
});
//# sourceMappingURL=PopulationRangeSlider.js.map