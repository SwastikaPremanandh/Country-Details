var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
define(["require", "exports", "preact/jsx-runtime", "preact/hooks", "./SearchCountry", "ojs/ojlabel", "ojs/ojinputtext", "ojs/ojformlayout", "ojs/ojbutton"], function (require, exports, jsx_runtime_1, hooks_1, SearchCountry_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    const Content = () => {
        const [email, setEmail] = (0, hooks_1.useState)("");
        const [password, setPassword] = (0, hooks_1.useState)("");
        const [loggedIn, setLoggedIn] = (0, hooks_1.useState)(false);
        const username = 'country';
        const pass = 'country@123';
        const basicAuth = btoa(`${username}:${pass}`);
        const login = () => __awaiter(void 0, void 0, void 0, function* () {
            try {
                let res = yield fetch("http://localhost:8080/api/user", {
                    method: "GET",
                    headers: {
                        "Content-type": "application/json",
                        "Authorization": `Basic ${basicAuth}`
                    }
                });
                let response = yield res.json();
                console.log("response", response);
                let credentialsMatch = false;
                for (let userKey in response) {
                    let user = response[userKey];
                    if (user.email === email && user.password === password) {
                        credentialsMatch = true;
                        break;
                    }
                }
                if (credentialsMatch) {
                    setLoggedIn(true);
                    console.log("Credentials match found.");
                }
                else {
                    alert("Error: Email or password is incorrect");
                }
            }
            catch (error) {
                console.error("Error:", error);
                alert("Error: Something went wrong. Please try again later.");
            }
        });
        if (loggedIn) {
            return (0, jsx_runtime_1.jsx)(SearchCountry_1.default, {});
        }
        const validate = () => __awaiter(void 0, void 0, void 0, function* () {
            if (!email) {
                window.alert("Please Enter Your Email id");
            }
            else if (!password) {
                window.alert("Please Enter Your Password");
            }
            else {
                login();
            }
        });
        const handleSubmit = (event) => __awaiter(void 0, void 0, void 0, function* () {
            event.preventDefault();
            validate();
        });
        return ((0, jsx_runtime_1.jsxs)("div", Object.assign({ className: "oj-web-applayout-max-width oj-web-applayout-content" }, { children: [(0, jsx_runtime_1.jsx)("h1", { children: "Login" }), (0, jsx_runtime_1.jsxs)("div", Object.assign({ className: "oj-flex oj-sm-flex-direction-column" }, { children: [(0, jsx_runtime_1.jsx)("div", Object.assign({ className: "oj-flex-item oj-sm-padding-2x-horizontal" }, { children: (0, jsx_runtime_1.jsxs)("div", Object.assign({ className: "oj-flex" }, { children: [(0, jsx_runtime_1.jsx)("div", Object.assign({ className: "oj-flex-item oj-md-padding-2x-horizontal" }, { children: (0, jsx_runtime_1.jsx)("oj-label", Object.assign({ for: "enteremail" }, { children: (0, jsx_runtime_1.jsx)("h5", { children: "Email Address:" }) })) })), (0, jsx_runtime_1.jsx)("oj-input-text", { value: email, onvalueChanged: (e) => setEmail(e.detail.value), class: "demo-percentage-width", "label-hint": "Enter Email" })] })) })), (0, jsx_runtime_1.jsx)("div", Object.assign({ className: "oj-flex-item oj-sm-padding-2x-horizontal" }, { children: (0, jsx_runtime_1.jsxs)("div", Object.assign({ className: "oj-flex" }, { children: [(0, jsx_runtime_1.jsx)("div", Object.assign({ className: "oj-flex-item oj-md-padding-2x-horizontal" }, { children: (0, jsx_runtime_1.jsx)("oj-label", Object.assign({ for: "enterpassword" }, { children: (0, jsx_runtime_1.jsx)("h5", { children: "Password:" }) })) })), (0, jsx_runtime_1.jsx)("oj-input-password", { value: password, class: "demo-percentage-width", onvalueChanged: (e) => setPassword(e.detail.value), "label-hint": "Enter Password", "mask-icon": "visible" })] })) })), (0, jsx_runtime_1.jsx)("div", Object.assign({ className: "oj-flex-item oj-sm-padding-2x-horizontal", style: { display: 'flex', justifyContent: 'center', marginTop: '30px' } }, { children: (0, jsx_runtime_1.jsxs)("div", Object.assign({ className: "oj-flex" }, { children: [(0, jsx_runtime_1.jsx)("div", Object.assign({ className: "oj-flex-item oj-md-padding-2x-horizontal" }, { children: (0, jsx_runtime_1.jsx)("span", {}) })), (0, jsx_runtime_1.jsx)("oj-button", Object.assign({ id: "submit", slot: "value", onClick: handleSubmit }, { children: "Login" }))] })) }))] }))] })));
    };
    exports.default = Content;
});
//# sourceMappingURL=index.js.map