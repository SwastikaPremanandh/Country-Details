import { h } from "preact";
import "ojs/ojslider";
import "ojs/ojformlayout";
import "ojs/ojlabel";
declare const PopulationRangeSlider: ({ min, max, value, onRangeChange }: {
    min: any;
    max: any;
    value: any;
    onRangeChange: any;
}) => h.JSX.Element;
export default PopulationRangeSlider;
