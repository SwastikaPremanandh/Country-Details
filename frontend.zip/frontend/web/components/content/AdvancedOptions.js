var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
define(["require", "exports", "preact/jsx-runtime", "preact/hooks", "ojs/ojarraydataprovider", "./PopulationRangeSlider", "./AreaRangeSlider", "ojs/ojdialog", "ojs/ojselectsingle", "ojs/ojbutton"], function (require, exports, jsx_runtime_1, hooks_1, ArrayDataProvider, PopulationRangeSlider_1, AreaRangeSlider_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    const AdvancedOptions = (props) => {
        const [regions, setRegions] = (0, hooks_1.useState)([]);
        const [currencies, setCurrencies] = (0, hooks_1.useState)([]);
        const dialogRef = (0, hooks_1.useRef)(null);
        const handleDoneClick = () => {
            props.onDone();
            closeDialog(dialogRef);
        };
        const closeDialog = (ref) => {
            console.log('hi');
        };
        (0, hooks_1.useEffect)(() => {
            props.isOpened
                ? dialogRef.current.open()
                : dialogRef.current.close();
        }, [props.isOpened]);
        (0, hooks_1.useEffect)(() => {
            const fetchRegions = () => __awaiter(void 0, void 0, void 0, function* () {
                try {
                    const response = yield fetch(`http://localhost:8080/unique-regions`, {
                        headers: {
                            'Authorization': `Basic ${btoa('country:country@123')}`
                        }
                    });
                    if (!response.ok) {
                        throw new Error('Failed to fetch regions');
                    }
                    const data = yield response.json();
                    const mappedData = data.map((value) => ({
                        value,
                        label: value
                    }));
                    setRegions(mappedData);
                }
                catch (error) {
                    console.error('Error fetching regions:', error);
                }
            });
            const fetchCurrencies = () => __awaiter(void 0, void 0, void 0, function* () {
                try {
                    const response = yield fetch('http://localhost:8080/unique-currencies', {
                        headers: {
                            'Authorization': `Basic ${btoa('country:country@123')}`
                        }
                    });
                    if (!response.ok) {
                        throw new Error('Failed to fetch currencies');
                    }
                    const data = yield response.json();
                    const mappedData = data.map((value) => ({
                        value,
                        label: value
                    }));
                    setCurrencies(mappedData);
                }
                catch (error) {
                    console.error('Error fetching currencies:', error);
                }
            });
            fetchRegions();
            fetchCurrencies();
        }, []);
        return ((0, jsx_runtime_1.jsx)(jsx_runtime_1.Fragment, { children: (0, jsx_runtime_1.jsxs)("oj-dialog", Object.assign({ ref: dialogRef, dialogTitle: "Advanced Options", onojClose: closeDialog, modality: "modeless" }, { children: [(0, jsx_runtime_1.jsx)("div", Object.assign({ slot: "body" }, { children: (0, jsx_runtime_1.jsxs)("oj-form-layout", { children: [(0, jsx_runtime_1.jsx)("oj-select-single", { id: "regionSelect", "label-hint": "Region", data: new ArrayDataProvider(regions, { keyAttributes: 'value' }), onvalueChanged: (event) => props.setSelectedRegion(event.detail.value) }), (0, jsx_runtime_1.jsx)("oj-select-single", { id: "currencySelect", "label-hint": "Currency", data: new ArrayDataProvider(currencies, { keyAttributes: 'value' }), onvalueChanged: (event) => props.setSelectedCurrency(event.detail.value) }), (0, jsx_runtime_1.jsx)(PopulationRangeSlider_1.default, { min: props.min, max: props.max, value: props.value, onRangeChange: props.onRangeChange }), (0, jsx_runtime_1.jsx)(AreaRangeSlider_1.default, { areamin: props.areamin, areamax: props.areamax, areavalue: props.areavalue, onAreaChange: props.onAreaChange }), (0, jsx_runtime_1.jsx)("oj-button", Object.assign({ id: "doneBtn", onojAction: handleDoneClick }, { children: "Done" }))] }) })), (0, jsx_runtime_1.jsx)("div", Object.assign({ slot: "footer" }, { children: (0, jsx_runtime_1.jsx)("oj-button", Object.assign({ id: "cancelBtn", onojAction: closeDialog }, { children: "Cancel" })) }))] })) }));
    };
    exports.default = AdvancedOptions;
});
//# sourceMappingURL=AdvancedOptions.js.map