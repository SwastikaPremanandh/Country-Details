var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
define(["require", "exports", "preact/jsx-runtime", "preact/hooks", "./AdvancedOptions", "ojs/ojarraydataprovider", "ojs/ojinputsearch", "ojs/ojbutton", "ojs/ojinputtext", "ojs/ojtable"], function (require, exports, jsx_runtime_1, hooks_1, AdvancedOptions_1, ArrayDataProvider) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    const SearchCountry = () => {
        const [val, setVal] = (0, hooks_1.useState)('');
        const [suggestions, setSuggestions] = (0, hooks_1.useState)([]);
        const [countryDetails, setCountryDetails] = (0, hooks_1.useState)([]);
        const [isAdvancedOptionsOpen, setIsAdvancedOptionsOpen] = (0, hooks_1.useState)(false);
        const [selectedRegion, setSelectedRegion] = (0, hooks_1.useState)("");
        const [selectedCurrency, setSelectedCurrency] = (0, hooks_1.useState)("");
        const [filterDetails, setFilterDetails] = (0, hooks_1.useState)([]);
        const [isSubmitExecuted, setIsSubmitExecuted] = (0, hooks_1.useState)(false);
        const [isDataFound, setIsDataFound] = (0, hooks_1.useState)(true);
        const [rangeValue, setRangeValue] = (0, hooks_1.useState)({ start: 0, end: 1400000000 });
        const [areaValue, setAreaValue] = (0, hooks_1.useState)({ start: 0, end: 18000000 });
        const [isAdvancedOptionsDone, setIsAdvancedOptionsDone] = (0, hooks_1.useState)(false);
        const [dataArray, setDataArray] = (0, hooks_1.useState)([]);
        const handleRangeChange = (rangeValue) => {
            setRangeValue(rangeValue);
        };
        const handleAreaChange = (areaValue) => {
            setAreaValue(areaValue);
        };
        const openAdvancedOptions = () => {
            setIsAdvancedOptionsOpen(true);
        };
        const closeAdvancedOptions = (ref) => {
            setIsAdvancedOptionsOpen(false);
            if (ref && ref.current) {
                ref.current.close();
            }
        };
        (0, hooks_1.useEffect)(() => {
            fetchSuggestions();
        }, []);
        const fetchSuggestions = () => __awaiter(void 0, void 0, void 0, function* () {
            try {
                const response = yield fetch('http://localhost:8080/unique-country-names', {
                    headers: {
                        'Authorization': `Basic ${btoa('country:country@123')}`
                    }
                });
                if (!response.ok) {
                    throw new Error('Failed to fetch suggestions');
                }
                const data = yield response.json();
                const countryArray = data.map((country) => ({ value: country, label: country }));
                setSuggestions(countryArray);
            }
            catch (error) {
                console.error('Error fetching suggestions:', error);
            }
        });
        const handleValueChanged = (event) => {
            setVal(event.target.value);
        };
        const handleSubmit = () => __awaiter(void 0, void 0, void 0, function* () {
            if (val) {
                try {
                    const response = yield fetch(`http://localhost:8080/api/filter?search=${val}`, {
                        headers: {
                            'Authorization': `Basic ${btoa('country:country@123')}`
                        }
                    });
                    if (!response.ok) {
                        throw new Error('Failed to retrieve country details');
                    }
                    const countryDetails = yield response.json();
                    const newData = countryDetails.map(country => ({
                        "name": country.name,
                        "nativeName": country.nativeName,
                        "capital": country.capital,
                        "region": country.region,
                        "subregion": country.subregion,
                        "area": country.area,
                        "population": country.population,
                        "currencies": country.currencies.join(', ')
                    }));
                    setCountryDetails(newData);
                    setIsSubmitExecuted(true);
                }
                catch (error) {
                    console.error('Error retrieving country details:', error);
                    alert('Error retrieving country details. Please try again.');
                }
            }
        });
        const handleAdvancedOptionsDone = () => __awaiter(void 0, void 0, void 0, function* () {
            setIsAdvancedOptionsDone(true);
            try {
                let apiUrl = 'http://localhost:8080/api/filter?';
                if (selectedCurrency) {
                    apiUrl += `currency=${selectedCurrency}&`;
                }
                if (selectedRegion) {
                    apiUrl += `region=${selectedRegion}&`;
                }
                if (areaValue && areaValue.start !== undefined && areaValue.end !== undefined) {
                    apiUrl += `minArea=${areaValue.start}&maxArea=${areaValue.end}&`;
                }
                if (rangeValue && rangeValue.start !== undefined && rangeValue.end !== undefined) {
                    apiUrl += `minPopulation=${rangeValue.start}&maxPopulation=${rangeValue.end}&`;
                }
                apiUrl = apiUrl.replace(/&$/, '');
                const response = yield fetch(apiUrl, {
                    headers: {
                        'Authorization': `Basic ${btoa('country:country@123')}`
                    }
                });
                if (!response.ok) {
                    throw new Error(`Failed to fetch data from ${apiUrl}`);
                }
                const filterDetails = yield response.json();
                const filterData = filterDetails.map(country => ({
                    "name": country.name,
                    "nativeName": country.nativeName,
                    "capital": country.capital,
                    "region": country.region,
                    "subregion": country.subregion,
                    "area": country.area,
                    "population": country.population,
                    "currencies": country.currencies.join(', ')
                }));
                setFilterDetails(filterData);
                if (filterData.length > 0) {
                    setIsDataFound(true);
                }
                else {
                    setIsDataFound(false);
                }
            }
            catch (error) {
                console.error("Error fetching data:", error);
            }
        });
        (0, hooks_1.useEffect)(() => {
            if (isSubmitExecuted) {
                setDataArray(countryDetails);
                setIsSubmitExecuted(false);
            }
            else if (isAdvancedOptionsDone) {
                setDataArray(filterDetails);
                setIsAdvancedOptionsDone(false);
            }
        }, [isSubmitExecuted, isAdvancedOptionsDone, countryDetails, filterDetails]);
        return ((0, jsx_runtime_1.jsx)("div", Object.assign({ className: "oj-web-applayout-max-width oj-web-applayout-content" }, { children: (0, jsx_runtime_1.jsxs)("div", Object.assign({ slot: "body" }, { children: [(0, jsx_runtime_1.jsxs)("oj-form-layout", Object.assign({ "max-columns": "3", direction: "row" }, { children: [(0, jsx_runtime_1.jsx)("oj-input-search", { id: "search1", class: "oj-input-search-hero custom-input-search", suggestions: new ArrayDataProvider(suggestions, { keyAttributes: "value" }), placeholder: "Search...", onvalueChanged: handleValueChanged, value: val, "aria-label": "My search field" }), (0, jsx_runtime_1.jsx)("oj-button", Object.assign({ id: "submit", slot: "value", onClick: handleSubmit }, { children: "Search Details" })), (0, jsx_runtime_1.jsx)("oj-button", Object.assign({ id: "Advoptions", onClick: openAdvancedOptions }, { children: "Advanced Options" }))] })), (0, jsx_runtime_1.jsx)(AdvancedOptions_1.default, { isOpened: isAdvancedOptionsOpen, closeDialog: closeAdvancedOptions, setSelectedRegion: setSelectedRegion, setSelectedCurrency: setSelectedCurrency, min: 0, max: 1400000000, value: rangeValue, onRangeChange: handleRangeChange, areamin: 0, areamax: 18000000, areavalue: areaValue, onAreaChange: handleAreaChange, onDone: handleAdvancedOptionsDone }), dataArray.length > 0 ? ((0, jsx_runtime_1.jsx)("oj-table", { id: "countryDetailsTable", "aria-label": "Country Details Table", data: new ArrayDataProvider(dataArray), dnd: { "reorder": { "columns": "enabled" } }, "scroll-policy": "loadMoreOnScroll", "scroll-policy-options": '{"fetchSize": 10}', columns: [
                            {
                                "headerText": "Name",
                                "field": "name",
                                "headerClassName": "oj-sm-only-hide",
                                "className": "oj-sm-only-hide",
                                "resizable": "enabled",
                                "id": "name"
                            },
                            {
                                "headerText": "Native Name",
                                "field": "nativeName",
                                "resizable": "enabled",
                                "id": "nativeName"
                            },
                            {
                                "headerText": "Capital",
                                "field": "capital",
                                "headerClassName": "oj-sm-only-hide",
                                "className": "oj-sm-only-hide",
                                "resizable": "enabled",
                                "id": "capital"
                            },
                            {
                                "headerText": "Region",
                                "field": "region",
                                "resizable": "enabled",
                                "id": "region"
                            },
                            {
                                "headerText": "Subregion",
                                "field": "subregion",
                                "headerClassName": "oj-md-down-hide",
                                "className": "oj-md-down-hide",
                                "resizable": "enabled",
                                "id": "subregion"
                            },
                            {
                                "headerText": "Area",
                                "field": "area",
                                "headerClassName": "oj-md-down-hide",
                                "className": "oj-md-down-hide",
                                "resizable": "enabled",
                                "id": "area"
                            },
                            {
                                "headerText": "Population",
                                "field": "population",
                                "headerClassName": "oj-md-down-hide",
                                "className": "oj-md-down-hide",
                                "resizable": "enabled",
                                "id": "population"
                            },
                            {
                                "headerText": "Currencies",
                                "field": "currencies",
                                "headerClassName": "oj-md-down-hide",
                                "className": "oj-md-down-hide",
                                "resizable": "enabled",
                                "id": "currencies"
                            }
                        ], class: "country-details-table-container" })) : (!isDataFound && ((0, jsx_runtime_1.jsx)("div", Object.assign({ className: "no-match-found-text" }, { children: "No match found" }))))] })) })));
    };
    exports.default = SearchCountry;
});
//# sourceMappingURL=SearchCountry.js.map