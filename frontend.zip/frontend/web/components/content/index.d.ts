import "ojs/ojlabel";
import "ojs/ojinputtext";
import "ojs/ojformlayout";
import "ojs/ojbutton";
declare const Content: () => import("preact").JSX.Element;
export default Content;
