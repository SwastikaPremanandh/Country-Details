import "ojs/ojdialog";
import 'ojs/ojselectsingle';
import "ojs/ojbutton";
type Props = {
    isOpened: boolean;
    closeDialog: (ref: any) => void;
    setSelectedRegion: (region: string) => void;
    setSelectedCurrency: (currency: string) => void;
    min: number;
    max: number;
    value: {
        start: number;
        end: number;
    };
    onRangeChange: (value: {
        start: number;
        end: number;
    }) => void;
    areamin: number;
    areamax: number;
    areavalue: {
        start: number;
        end: number;
    };
    onAreaChange: (areavalue: {
        start: number;
        end: number;
    }) => void;
    onDone: () => void;
};
declare const AdvancedOptions: (props: Props) => import("preact").JSX.Element;
export default AdvancedOptions;
