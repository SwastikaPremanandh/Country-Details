import "ojs/ojinputsearch";
import "ojs/ojbutton";
import "ojs/ojinputtext";
import "ojs/ojtable";
declare const SearchCountry: () => import("preact").JSX.Element;
export default SearchCountry;
