define(["require", "exports", "preact/jsx-runtime", "ojs/ojslider", "ojs/ojformlayout", "ojs/ojlabel"], function (require, exports, jsx_runtime_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    const AreaRangeSlider = ({ areamin, areamax, areavalue, onAreaChange }) => {
        const handleAreaChange = (event) => {
            onAreaChange(event.detail.value);
        };
        return ((0, jsx_runtime_1.jsx)("div", Object.assign({ id: "sampleDemo", className: "demo-padding demo-container" }, { children: (0, jsx_runtime_1.jsx)("div", Object.assign({ id: "componentDemoContent", style: { width: "1px", minWidth: "100%" } }, { children: (0, jsx_runtime_1.jsx)("div", Object.assign({ id: "range-slider-container" }, { children: (0, jsx_runtime_1.jsxs)("oj-form-layout", { children: [(0, jsx_runtime_1.jsx)("oj-range-slider", { id: "area-range-slider", value: areavalue, min: areamin, max: areamax, onvalueChanged: handleAreaChange, "label-hint": "Area", "label-edge": "inside", step: 100000 }), (0, jsx_runtime_1.jsx)("oj-label", { children: "Start and end value for Area Range Slider" }), (0, jsx_runtime_1.jsx)("span", Object.assign({ id: "values" }, { children: `${areavalue.start} , ${areavalue.end}` }))] }) })) })) })));
    };
    exports.default = AreaRangeSlider;
});
//# sourceMappingURL=AreaRangeSlider.js.map