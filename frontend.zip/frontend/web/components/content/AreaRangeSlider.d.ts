import "ojs/ojslider";
import "ojs/ojformlayout";
import "ojs/ojlabel";
declare const AreaRangeSlider: ({ areamin, areamax, areavalue, onAreaChange }: {
    areamin: any;
    areamax: any;
    areavalue: any;
    onAreaChange: any;
}) => import("preact").JSX.Element;
export default AreaRangeSlider;
