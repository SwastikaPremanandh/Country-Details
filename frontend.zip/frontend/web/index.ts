/**
 * @license
 * Copyright (c) 2014, 2023, Oracle and/or its affiliates.
 * Licensed under The Universal Permissive License (UPL), Version 1.0
 * as shown at https://oss.oracle.com/licenses/upl/
 * @ignore
 */
// injector:preactDebugImport
// To learn more about preact devtools see https://preactjs.github.io/preact-devtools/
import 'preact/debug';
// endinjector
import './components/app';