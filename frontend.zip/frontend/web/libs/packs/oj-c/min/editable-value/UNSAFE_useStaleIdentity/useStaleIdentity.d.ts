export declare function useStaleIdentity(): {
    setStaleIdentity: (id: `use${string}`) => {
        isStale: () => boolean;
    };
};
